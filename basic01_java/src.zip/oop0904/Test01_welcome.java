package oop0904;

public class Test01_welcome { //class 시작

	public static void main(String[] args) { //main 시작
		// 한줄주석
		/* 여러줄 주석 */
		// Object Oriented Program 객체 지향 프로그램
		/*
		 * ● [자바 기본 문법]
		 *   - 자바 명령어는 대소문자를 엄격하게 구분한다.
		 *   - 명령어 종결문자;
		 *   
		 * ● [식별자]
		 *   - 프로젝트명 basic01_java
		 *   - 패키지명 oop0904
		 *   - 클래스명 Test01_welcome.java
		 *
		 * ● [식별자 작성 규칙]
		 *   - 클래스명의 첫글자는 대부분 대문자로 한다
		 *   - 패키지명의 첫글자는 대부분 소문자로 한다.
		 *   
		 * ● [자바 API]
		 *   https://docs.oracle.com/javase/8/docs/api/
		 *   https://docs.oracle.com/javaee/7/api/
		 */
	}//main 끝
}//class 끝
