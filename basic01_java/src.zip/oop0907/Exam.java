package oop0907;

public class Exam {
	private String name = "손흥민";
	private int kor, eng, mat;
	private int aver;
	
	public Exam() {
		
	}

	public Exam(String name) {
		this.name = name;
	}

	public Exam(int kor, int eng, int mat) {
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
	}

	public Exam(String name, int kor, int eng, int mat) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
	}
	
	
	
	//생성자 함수 constructor
	
}
