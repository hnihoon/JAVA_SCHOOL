package oop0915;

public class Test02_thread {

	public static void main(String[] args) {
		//2)쓰레드를 사용한 경우
		//-> JVM이 쓰레드 관리자에 등록하고, start()메소드가 run()를 호출한다.
	}

}
